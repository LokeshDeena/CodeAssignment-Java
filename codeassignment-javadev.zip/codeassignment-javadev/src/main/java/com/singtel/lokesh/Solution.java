/**
 * 
 */

package com.singtel.lokesh;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.LoggerFactory;

/**
 * Property of Lokesh Created For Interview at Jan 20, 2020
 */
public class Solution {

	public static final org.slf4j.Logger log = LoggerFactory.getLogger(
		Solution.class);

	public static void main(String[] args) throws Exception {
		Bird bird = new Bird();
		bird.walk();
		bird.fly();
		bird.sing();
		Bird duckBird = new Duck();
		duckBird.says();
		duckBird.swim();
		Bird chikenBird = new Chicken();
		chikenBird.says();
		chikenBird.fly();
		chikenBird.swim();
		Rooster rooster = new Rooster(new Bird("Rooster"));
		rooster.says();
		Parrot dogWithparrot = new Parrot(new Dog());
		Parrot catWithparrot = new Parrot(new Cat());
		Parrot parrotInFarm = new Parrot(new Bird("Rooster"));
		dogWithparrot.says();
		catWithparrot.says();
		parrotInFarm.says();
		Animal shark = new Shark();
		shark.swim();
		shark.sing();
		Animal clownFish = new ClownFish();
		clownFish.swim();
		Animal dolphin = new Dolhpin();
		dolphin.swim();
		Bird butterfly = new ButterFly();
		butterfly.fly();
		butterfly.sing();
		Bird caterpillar = new CaterPillar();
		caterpillar.walk();
		try {
			caterpillar.fly();
		}
		catch (Exception ex) {
			log.info(ex.getMessage());
		}
		Animal[] animals = new Animal[] { new Bird(), new Chicken(), new Duck(),
			new Dog(), new Cat(), new Fish(), new Bird("Rooster"), new Shark(), new ClownFish(), new Dolhpin(), new ButterFly(), new CaterPillar() };
		Map<String, Integer> agrtAnimalTypes = new HashMap<>();
		AtomicInteger swimCount = new AtomicInteger();
		AtomicInteger singCount = new AtomicInteger();
		AtomicInteger flyCount = new AtomicInteger();
		AtomicInteger walkCount = new AtomicInteger();
		Arrays.asList(animals).stream().forEach(anml -> {
			if (anml.fishType || anml.swimType) {
				swimCount.incrementAndGet();
			}
			if (anml.birdsType && !anml.nonSoundType) {
				singCount.incrementAndGet();
			}
			if (anml.birdsType && !anml.nonFlyType) {
				flyCount.incrementAndGet();
			}
			if (anml.birdsType && !anml.nonWalkType) {
				walkCount.incrementAndGet();
			}
		});
		agrtAnimalTypes.put("FlyCount", flyCount.get());
		agrtAnimalTypes.put("WalkCount", walkCount.get());
		agrtAnimalTypes.put("SwimCount", swimCount.get());
		agrtAnimalTypes.put("SingCount", singCount.get());
		log.info("Animals Count::" + agrtAnimalTypes.toString());
	}

}

class Animal {

	public static final org.slf4j.Logger log = LoggerFactory.getLogger(
		Solution.class);
	boolean fishType = false;

	boolean birdsType = false;

	boolean nonSoundType = false;

	boolean nonWalkType = false;

	boolean nonFlyType = false;

	boolean swimType = false;

	String childType;

	Animal() {
		validate();

	}

	String name = "default";

	Animal(String name) {
		this.name = name;
		validate();
	}

	void walk() {
		if (birdsType || !nonWalkType) {
			log.info("I am walking");
		}
		else {
			log.info("I can't walk");
		}
	}

	public void says() {

		switch (childType) {
			case "Duck": {
				log.info(childType + "::" + " Quack, quack");
				break;
			}
			case "Chicken": {
				log.info(childType + "::" + "Cluck, cluck");
				break;
			}
			case "Rooster": {
				log.info(childType + "::" + "Cock-a-doodle-doo");
				break;
			}
			case "Dog": {
				log.info(childType + "::" + "Woof, woof");
				break;
			}
			case "Cat": {
				log.info(childType + "::" + "Meow");
				break;
			}
			default: {
				log.info(childType + "::" + "I am not a bird");
				break;
			}
		}
	}

	public void validate() {
		if (this.getClass().getCanonicalName().contains("Fish") || this.getClass()
			.getCanonicalName().contains("Dolhpin"))
		{
			fishType = true;
		}

		else if (this.getClass().getCanonicalName().contains("Bird") || this
			.getClass().getSuperclass().getCanonicalName().contains("Bird"))
		{
			birdsType = true;
		}

		if (this.getClass().getCanonicalName().contains("Chicken")) {
			nonFlyType = true;
		}
		if (this.getClass().getCanonicalName().contains("ButterFly")) {
			nonSoundType = true;
		}
		if (this.getClass().getCanonicalName().contains("CaterPillar")) {
			nonFlyType = true;
		}
		childType = this.getClass().getSimpleName();
	}

	public void sing() {
		if (fishType || nonSoundType) {
			log.info("I can't sing nor sound");
		}
		else {
			log.info("I am Singing");
		}
	}

	void swim() {
		if (fishType) {
			log.info("I am Swimming");
		}
		else {
			log.info("I can't swim");
		}
	}

}

class Bird extends Animal {

	Bird() {}

	Bird(String name) {
		this.name = name;
		this.childType = name;
	}

	protected void fly() {
		if (!nonFlyType) {
			log.info("I am flying");
		}
		else {
			log.info("I can't fly");
		}
	}

}

class Duck extends Bird {

	Duck() {
		swimType = true;
	}
}

class Chicken extends Bird {

}

class Dog extends Animal {

}

class Cat extends Animal {

}

class Rooster {

	Bird bird;

	public Rooster(Bird bird) {
		this.bird = bird;
	}

	void says() {
		bird.says();
	}

}

class Parrot {

	Animal animal;

	public Parrot(Animal animal) {
		this.animal = animal;
	}

	void says() {
		animal.says();
	}

}

class Fish extends Animal {

	Fish() {
		printcharacteristics();
	}

	String size;

	String color;


	void printcharacteristics() {
		switch (getType()) {
			case "Shark": {
				log.info("I am Shark");
				eatFish();
				break;
			}
			case "ClownFish": {
				log.info("I am clownfish");
				makeJokes();
				break;
			}
		}
	}

	void makeJokes() {
		log.info("I can make jokes");
	}

	void eatFish() {
		log.info("I can eat other fish");
	}

	String getType() {
		return this.getClass().getSimpleName();
	}

}

class Shark extends Fish {
	
	Shark() {
		this.size = "large";
		this.color = "grey";
	}
	
}

class ClownFish extends Fish {
	
	ClownFish() {
		this.size = "small";
		this.color = "orange";
	}
	
}

class Dolhpin extends Animal {

	Dolhpin() {}
}

class ButterFly extends Bird {
	
}

class CaterPillar extends Bird {
	
}
